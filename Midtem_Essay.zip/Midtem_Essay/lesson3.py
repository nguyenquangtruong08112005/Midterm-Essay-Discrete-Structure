from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP
import time
import matplotlib.pyplot as plt

# Generate RSA keys
key = RSA.generate(2048)
public_key = key.publickey()
private_key = key

# encryption and decryption
def rsa_encrypt(message):
    cipher = PKCS1_OAEP.new(public_key)
    ciphertext = cipher.encrypt(message)
    return ciphertext

def rsa_decrypt(ciphertext):
    cipher = PKCS1_OAEP.new(private_key)
    decrypted_message = cipher.decrypt(ciphertext)
    return decrypted_message


# Đo thời gian mã hóa và giải mã
message = b"Hello, this is a test message"
start_enc = time.perf_counter()
cipher = rsa_encrypt(message)
end_enc = time.perf_counter()
encryption_time = (end_enc - start_enc) * 1000  

start_dec = time.perf_counter()
decrypted_message = rsa_decrypt(cipher)
end_dec = time.perf_counter()
decryption_time = (end_dec - start_dec) * 1000  

# Test the encryption and decryption
assert message == decrypted_message, "Decryption failed: Message doesn't match the original."

print(f"Encryption time: {encryption_time:.3f} ms")
print("-"*100)
print(f"Decryption time: {decryption_time:.3f} ms")
print("-"*100)
print(f"Original message: {message.decode()}")
print("-"*100)
print(f"Decrypted message: {decrypted_message.decode()}")

# Measure time for different message lengths
lengths = []
encryption_times = []
decryption_times = []

for length in range(10, 201, 10): 
    message = b'a' * length 
    
    # Encryption timing
    start_time = time.perf_counter()
    cipher = rsa_encrypt(message)
    enc_time = time.perf_counter() - start_time
    
    # Decryption timing
    start_time = time.perf_counter()
    plain = rsa_decrypt(cipher)
    dec_time = time.perf_counter() - start_time
    
    lengths.append(length)
    encryption_times.append(enc_time)
    decryption_times.append(dec_time)

# Draw graph
plt.figure(figsize=(10,6))
plt.plot(lengths, encryption_times, label='Encryption Time', marker='o')
plt.plot(lengths, decryption_times, label='Decryption Time', marker='x')
plt.xlabel('Plaintext Message Length (bytes)')
plt.ylabel('Time (seconds)')
plt.title('RSA Encryption/Decryption Time vs Message Length')
plt.legend()
plt.grid(True)
plt.show()
